#!/usr/bin/env python3
"""
json_to_csv_common.py

Combine many JSON files into one CSV file, keeping **only** the fields
(keys) that appear in *every* record across all files.

Usage
-----
    python json_to_csv_common.py /path/to/json/folder output.csv

Notes
-----
* Each JSON file can hold either a single object or a list of objects.
* Objects must be “flat” (no nested dictionaries or lists) unless you
  pre‑flatten them yourself.
"""

import argparse
import csv
import glob
import json
import os
from typing import List, Dict, Set


def load_records(json_path: str) -> List[Dict]:
    """Return a list of dictionaries from a JSON file."""
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, list) else [data]


def build_common_key_set(records: List[Dict], running_common: Set[str]) -> Set[str]:
    """Intersect the current key set with keys from new records."""
    for rec in records:
        if running_common is None:
            running_common = set(rec.keys())
        else:
            running_common &= set(rec.keys())
    return running_common


def main(in_dir: str, out_csv: str) -> None:
    json_files = glob.glob(os.path.join(in_dir, "*.json"))
    if not json_files:
        raise FileNotFoundError("No JSON files found in the specified directory.")

    all_records: List[Dict] = []
    common_keys: Set[str] | None = None

    # Read files and track common keys
    for jf in json_files:
        recs = load_records(jf)
        all_records.extend(recs)
        common_keys = build_common_key_set(recs, common_keys)

    if not common_keys:
        raise ValueError("No common keys found across the provided JSON files.")

    # Write CSV
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=sorted(common_keys))
        writer.writeheader()
        for rec in all_records:
            writer.writerow({k: rec[k] for k in common_keys})

    print(f"✓ Wrote {len(all_records)} records to {out_csv}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Convert multiple JSON files to one CSV using only common fields."
    )
    parser.add_argument("input_dir", help="Folder containing .json files")
    parser.add_argument("output_csv", help="Path for the combined CSV file")
    args = parser.parse_args()

    main(args.input_dir, args.output_csv)
