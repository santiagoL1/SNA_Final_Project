import re
import pandas as pd

def extract_urls_from_excel_column(input_filename, column_name, output_filename="extracted_urls.xlsx"):
    """
    Reads a specified column from an XLSX file, extracts URLs, and saves them to a new XLSX file.

    Args:
        input_filename (str): The name of the input XLSX file.
        column_name (str): The name or the 0-based index of the column to read.
        output_filename (str, optional): The name of the output XLSX file.
                                         Defaults to "extracted_urls.xlsx".
    """
    urls = set()  # Use a set to store unique URLs

    try:
        df = pd.read_excel(input_filename)

        if column_name in df.columns:
            text_column = df[column_name]
        elif isinstance(column_name, int) and 0 <= column_name < len(df.columns):
            text_column = df.iloc[:, column_name]
        else:
            print(f"Error: Column '{column_name}' not found in the input file.")
            return

        for text in text_column:
            if isinstance(text, str):  # Ensure we are processing a string
                # Regular expression to find URLs
                url_pattern = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
                found_urls = url_pattern.findall(text)
                urls.update(found_urls)

        output_df = pd.DataFrame(sorted(list(urls)), columns=['URL'])
        output_df.to_excel(output_filename, index=False)

        print(f"Successfully extracted {len(urls)} unique URLs from column '{column_name}' and saved them to '{output_filename}'.")

    except FileNotFoundError:
        print(f"Error: Input file '{input_filename}' not found.")
    except ImportError:
        print("Error: The 'pandas' and 'openpyxl' libraries are required to work with XLSX files. Please install them using 'pip install pandas openpyxl'.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    input_file = input("Enter the name of the input XLSX file: ")
    column_identifier = input("Enter the name or the 0-based index of the column containing the text: ")
    output_file = input("Enter the name for the output XLSX file (optional, default is extracted_urls.xlsx): ") or "extracted_urls.xlsx"

    try:
        # Try to convert the column identifier to an integer (for index)
        column_index = int(column_identifier)
        extract_urls_from_excel_column(input_file, column_index, output_file)
    except ValueError:
        # If it's not an integer, assume it's the column name
        extract_urls_from_excel_column(input_file, column_identifier, output_file)